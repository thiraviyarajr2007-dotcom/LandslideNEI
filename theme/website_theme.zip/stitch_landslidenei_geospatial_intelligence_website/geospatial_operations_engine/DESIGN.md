---
name: Geospatial Operations Engine
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f12'
  surface-container-low: '#181c1f'
  surface-container: '#1c2023'
  surface-container-high: '#262a2e'
  surface-container-highest: '#313539'
  on-surface: '#e0e3e7'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e0e3e7'
  inverse-on-surface: '#2d3134'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#101417'
  on-background: '#e0e3e7'
  surface-variant: '#313539'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
---

## Brand & Style

This design system delivers a high-precision, mission-critical operations aesthetic tailored for AI-driven landslide risk intelligence, geotechnical monitoring, and disaster mitigation across Northeast India. The visual direction balances the stoic, uncompromising rigor of enterprise command-and-control software with the modern clarity of an advanced environmental intelligence terminal.

The target audience spans state disaster management authorities (SDMA/NDMA), geotechnical engineers, infrastructure planners, defense logistics operators, and scientific researchers. The emotional response must be immediate trust, composure under crisis, forensic accuracy, and quiet technical authority.

The aesthetic direction synthesizes **Technical High-Contrast** and **Refined Glassmorphism / Tonal Stratification**:
- Deep, atmospheric obsidian and charcoal field backgrounds eliminate eye strain during prolonged monitoring operations.
- Fine structural borders (1px) define discrete data modules with surgical precision, evoking survey reticles and radar instrumentation.
- Subtle GIS vector motifs, elevation contour overlays, and coordinate reference marks anchor the UI in real-world cartography without visual clutter.
- High-saturation status indicators are strictly reserved for operational telemetry, sensor thresholds, and emergency warnings.

## Colors

The palette is engineered specifically for dark-mode-first operations theaters, control centers, and geotechnical field displays. The palette uses disciplined color allocation to preserve cognitive bandwidth during emergency alerts.

### Surface Architecture
- **Base Obsidian (`#0B0F12`)**: The foundational canvas representing ground-level sensor darkness.
- **Surface Elevation 1 (`#11171D`)**: Standard card, drawer, and panel backgrounds.
- **Surface Elevation 2 (`#161F26`)**: Elevated modals, telemetry sidecars, and selected state backdrops.
- **Surface Elevation 3 (`#1E293B`)**: Interactive controls, inactive switch tracks, and tertiary containment.

### Functional & Semantic Accents
- **Primary (Muted Emerald - `#10B981`, Deep Pine - `#064E3B`, Forest - `#059669`)**: Signifies baseline environmental stability, verified telemetry signals, healthy sensor nodes, and validated machine learning models.
- **Secondary (Geospatial Cyan - `#06B6D4`, Deep Cyan - `#0891B2`, Light Telemetry Cyan - `#38BDF8`)**: Denotes geospatial vector layers, precipitation radars, digital elevation models (DEM), and active coordinate crosshairs.
- **Warning (Operational Amber - `#F59E0B`)**: Alert Level 2 (Moderate hazard, saturated soil threshold reached, rainfall triggering advisory).
- **Critical (Hazard Red - `#EF4444`, Crimson Shadow - `#7F1D1D`)**: Alert Level 3 (Imminent slope failure, road blockages, evacuation trigger, real-time displacement detected).

### Content & Stroke Hierarchy
- **Text Highest Contrast (`#F8FAFC`)**: Primary telemetry values, warnings, and titles.
- **Text Medium Contrast (`#94A3B8`)**: Labels, metadata, and body narratives.
- **Text Diminished Contrast (`#64748B`)**: Axis units, grid coordinates, and inactive state cues.
- **Boundary Stroke Slate (`#1E293B`)**: Default structural borders and card outlines.
- **Active Structural Stroke (`#334155`)**: Hovered or focused containers, section dividers.

## Typography

The typographic hierarchy addresses three distinct operational demands: structural narrative impact, high-density legibility, and exact machine telemetry readout.

1. **Space Grotesk (Headlines & High-Level Displays)**: Infuses geometric engineering character into dashboard section banners, risk indices, and modal titles. Its slightly technical, industrial construction signals algorithmic sophistication.
2. **Inter (Interface & Analytical Narrative Body)**: Serves as the primary workhorse font. Delivers exceptional neutral clarity for analytical dossiers, incident reports, sensor logs, and dense parameter forms across all screen resolutions.
3. **JetBrains Mono (Telemetry, Coordinates & Status Parameters)**: Applied to GPS coordinates (lat/long), timestamp protocols, rainfall accumulation metrics (mm/hr), factor-of-safety readings, and sensor hardware IDs. Tabular spacing prevents layout shifting when numerical values update dynamically over web sockets.

## Layout & Spacing

The layout is built upon an 8-point base grid system combined with a 12-column adaptive layout for complex geospatial dashboards. High information density is prioritized without sacrificing scan speed.

### Breakpoint Specifications
- **Mobile (`< 768px`)**: Single-column vertical stacking. Sidebars collapse into slide-out tactical trays. Map controls collapse into compact floating action clusters. Margin: `16px`, Gutter: `16px`.
- **Tablet (`768px - 1023px`)**: 8-column layout. Split-pane navigation for live event feeds and GIS maps. Margin: `32px`, Gutter: `24px`.
- **Desktop / Control Workstation (`1024px - 1439px`)**: 12-column fluid grid. Fixed tactical left rail (64px collapsed / 240px expanded), central dynamic GIS viewport, and collapsible right-hand telemetry inspector. Margin: `32px`, Gutter: `24px`.
- **Large Command Display (`>= 1440px`)**: Multi-pane synchronized workspace with static 3-tier viewports (Map Engine, Time-series Sensor Telemetry, Alert Matrix). Maximum content bounds for non-map editorial pages is capped at `1440px`.

### Density Model
- **Compact Density**: Applied to telemetry tables, inspector sidebars, and sensor status lists (`space-xs` to `space-sm`).
- **Comfortable Density**: Applied to executive risk briefs, emergency dispatches, and public awareness releases (`space-md` to `space-xl`).

## Elevation & Depth

Visual hierarchy uses **tonal layer stratification**, **crisp 1px low-contrast bounding frames**, and **contained luminescent back-glows** rather than heavy skeuomorphic drop shadows.

1. **Layer 0 (Geospatial Base Canvas)**: `#0B0F12`. Deep neutral viewport host. Accommodates map tile canvases, vector layers, and satellite overlays.
2. **Layer 1 (Card & Module Shells)**: `#11171D` with a crisp `1px solid #1E293B` stroke. Internal elements use strict mathematical padding.
3. **Layer 2 (Hovered Panels & Action Layers)**: `#161F26` with border highlight transitioning to `#334155`.
4. **Layer 3 (Modals, Context Menus, and Emergency Drawers)**: `#161F26` encased with `1px solid #334155` and a soft directional drop shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.7)`.
5. **Operational Glow**: Applied sparingly to critical threat vectors. For severe alert indicators, a subtle cyan or crimson luminous aura (`0 0 16px rgba(239, 68, 68, 0.25)` or `0 0 16px rgba(6, 182, 212, 0.25)`) calls attention without blinding the dark-adapted eye.
6. **Subtle Elevation Contours**: Backgrounds may incorporate fine 10% opacity SVG topographic contour lines and 32px isometric grid lines to reinforce geographic data depth.

## Shapes

The design system employs a disciplined, micro-radius geometry (`roundedness: 1` / Soft - 4px base radius). This produces an engineered, high-precision instrument feel, rejecting overly casual pill shapes or harsh zero-radius brutalism.

- **Micro Controls & Badges (2px - 4px)**: Status badges, table cells, telemetry tags, and form input controls retain crisp 4px corners (`rounded-sm`).
- **Cards & Data Modules (6px - 8px)**: Standard telemetry cards, charts, and map inspection widgets use `8px` (`rounded-md` / `rounded-lg`).
- **Modals & Flyouts (8px - 12px)**: Floating dialogs and emergency alert windows use `12px` (`rounded-xl`).
- **Reticle Elements**: Targeting indicators, crosshairs, and live status dots utilize strict 50% circle geometry (`rounded-full`) to contrast against sharp rectangular modules.

## Components

### Buttons
- **Primary Operational**: Solid muted emerald `#10B981` with dark slate text `#0B0F12`, font weight 600, 4px border radius. Hover shifts to `#059669` with an active press scale of `0.98`.
- **Secondary Geospatial**: Transparent base with `1px solid #0891B2`, text `#38BDF8`. Hover fills to `rgba(6, 182, 212, 0.12)`.
- **Emergency Action**: Solid hazard crimson `#EF4444` with white text `#F8FAFC`. Used only for high-consequence operations (triggering broadcast alerts, manual siren activation).
- **Ghost/Tertiary**: No fill, text `#94A3B8`, hover states fill `#161F26` with border `#1E293B`.

### Status Badges & Chips
- Designed with `JetBrains Mono`, 11px uppercase, letter spacing `0.05em`, 4px radius.
- Always include an operational status dot (6px circle):
  - *Stable*: Emerald text `#10B981`, background `rgba(16, 185, 129, 0.1)`, dot `#10B981`.
  - *Advisory / Watch*: Amber text `#F59E0B`, background `rgba(245, 158, 11, 0.1)`, dot `#F59E0B` (pulsing).
  - *Warning / Critical*: Crimson text `#EF4444`, background `rgba(239, 68, 68, 0.15)`, dot `#EF4444` (rapid pulse).
  - *Telemetry Stream*: Cyan text `#38BDF8`, background `rgba(6, 182, 212, 0.1)`, dot `#06B6D4`.

### Input Fields & Selectors
- Background `#11171D`, border `1px solid #1E293B`, radius 4px, height 40px (compact 32px for map overlays).
- Text `#F8FAFC`, placeholder `#64748B`.
- Focused state: Border transitions to `#06B6D4` with `0 0 0 1px #06B6D4`.
- Monospace variant available for manual coordinate inputs (e.g., `27.3389° N, 88.6065° E`).

### Checkboxes & Switches
- **Checkboxes**: 16x16px square with 2px radius, border `1px solid #334155`. Selected state fills `#10B981` with a `#0B0F12` checkmark icon.
- **Toggle Switches (Layer Visibility)**: Width 36px, height 20px. Track background `#1E293B`, thumb 16px white circle. Active track transitions to `#06B6D4`.

### Cards & Telemetry Containers
- Background `#11171D`, border `1px solid #1E293B`, padding 16px to 24px.
- Card Header: Features small caps label in `Space Grotesk`, accompanying `JetBrains Mono` coordinates or zone identifier (e.g., `ZONE-04: SIKKIM RIDGE`).
- Includes subtle corner tick marks (`+` or `L-brackets`) on specialized sensor inspection cards to evoke military-grade telemetry hardware.

### Specialized Domain Components
- **Telemetry Metric Tile**: Displays numerical readout (e.g., `142.4 mm/24h`) in `Space Grotesk` 28px bold, accompanied by trend sparkline and threshold limit bar.
- **Elevation Cross-Section Graph**: Dark slate container with cyan vector path displaying slope gradient, shear plane risk, and bedrock depth.
- **Hazard Level Indicator Strip**: Segmented bar (Low / Moderate / Severe / Critical) with active step illuminated and inactive steps at 20% opacity.