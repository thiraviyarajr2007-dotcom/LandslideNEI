---
name: Terrain Intelligence System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#a33900'
  on-tertiary: '#ffffff'
  tertiary-container: '#cc4900'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb599'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#7f2b00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.005em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-compact: 0.5rem
  gutter-standard: 1rem
  panel-sidebar: 22rem
  telemetry-strip: 3.5rem
---

## Brand & Style

This design system establishes a high-precision, executive-level geospatial intelligence interface engineered for real-time natural hazard monitoring, terrain stability modeling, and emergency command operations. It balances the uncompromising legibility required for high-stress crisis response with the refined clarity of modern scientific visualization software.

The visual style is **Scientific High-Contrast Precision**—an authoritative aesthetic characterized by crisp off-white structural planes, razor-thin topographic contour delineation, dense data architecture, and unambiguous state signifiers. Rather than generic corporate SaaS conventions or dark-room radar tropes, the system uses daylight-optimized luminescence with high optical contrast, allowing GIS analysts, civil engineers, and disaster response leaders to parse critical telemetry rapidly under any ambient light condition.

## Colors

The color architecture is built around calibrated contrast ratios meeting strict enterprise and defense accessibility criteria (WCAG AAA for all primary data points).

- **Primary Emerald (`#059669`)**: Conveys operational stability, active sensor sync, and authoritative validation across geospatial vector assets.
- **Secondary Cyan (`#0284C7`)**: Designates secondary hydrologic vectors, geospatial layers, telemetry overlays, and spatial query active states.
- **Tertiary Alert Amber (`#EA580C`) & Alert Coral (`#DC2626`)**: Reserved strictly for seismic anomalies, rapid displacement warnings, pore-water pressure spikes, and critical slope failure alerts.
- **Topographic Neutrals**: Deep slate (`#0F172A`) anchors numerical outputs and primary headlines, paired with layered surfaces (`#FFFFFF`, `#F8FAFC`, `#F1F5F9`) structured by slate contour borders (`#CBD5E1`, `#94A3B8`). Pure white is reserved for high-priority operational cards and data viewports floating above the ambient canvas.

## Typography

The typographic hierarchy implements three coordinated typefaces tailored for geospatial intelligence:

- **Space Grotesk** serves as the primary voice for high-level spatial entities, coordinates, module headers, and executive dashboards. Its geometric, structural idiosyncrasies convey a technical signature.
- **Inter** ensures uninterrupted reading comfort across telemetry stream narratives, operational incident logs, geotechnical reports, and configuration panels.
- **JetBrains Mono** governs all quantitative data, GPS/WGS-84 coordinates, vector bearings, timestamp streams, sensor delta readouts, and status codes. Its tabular figures and wide character width eliminate scanning ambiguity during critical event sequences.

## Layout & Spacing

The layout model is governed by an asymmetric split-canvas system optimized for multi-monitor workstations and responsive field command tablets:

- **Desktop & Mission Control (1440px+)**: A persistent 4-pixel hairline-anchored telemetry strip sits at the top edge. Left dock reserves `panel-sidebar` (352px) for geotechnical layer trees and sensor node hierarchies. The central stage functions as a fluid viewport with floating inspection HUDs. The right rail handles contextual analytics on a 12-column sub-grid with `gutter-standard` (16px).
- **Tablet Command (768px – 1439px)**: Sidebars collapse into slide-out drawer panels with `space-md` (12px) exterior canvas buffers. Viewports prioritize touch pan-and-zoom GIS data with 44px minimum target regions.
- **Field Terminal Mobile (<768px)**: Modules stack into a single column vertical stream. Bottom sheet sheets manage telemetry drill-downs, defaulting to an 8px base rhythm.

## Elevation & Depth

Visual separation relies on calibrated surface tonal gradation and crisp contour borders rather than soft blur shadows, reflecting cartographic drafting principles:

- **Canvas Base Level (0)**: `#F8FAFC` provides the neutral reference field for map interfaces and dashboard backgrounds.
- **Structural Framing (Contour)**: Explicit 1px solid borders using `#CBD5E1` outline every structural cell, card, and inspector panel, echoing topographic isolation lines.
- **Elevated Floating Overlays (HUD / Popovers)**: `#FFFFFF` panels suspended above vector maps utilize an ultra-crisp dual boundary: a 1px border (`#94A3B8`) combined with a directional engineering offset shadow (`0 2px 4px 0 rgba(15, 23, 42, 0.06), 0 8px 16px -2px rgba(15, 23, 42, 0.04)`).
- **Active Data Focus**: Focused panels increase their border contrast to `#059669` or `#0284C7` with a subtle 2px perimeter hairline, eliminating visual float while emphasizing target lock.

## Shapes

The design system employs **Soft (`1`)** geometry (base radius of 0.25rem / 4px).

This tight corner geometry produces an analytical, instrument-grade posture that feels precise, structured, and space-efficient. It prevents the playful feel of heavily rounded elements while avoiding the abrasive harshness of absolute 0px square edges. Nested components maintain mathematical proportionality: 4px for interior tags, inputs, and buttons; 6px (`rounded-lg`) for major telemetry cards; 8px (`rounded-xl`) for main application viewports and modal layers.

## Components

### Buttons & Trigger Controls
- **Primary Operational Button**: Solid `#059669` fill, `#FFFFFF` Space Grotesk text (13px, weight 600), 4px radius. Height 36px. Hover state shifts to `#047857`. Active press compresses border-box by 0.5px.
- **Secondary Telemetry Trigger**: Surface `#FFFFFF`, 1px border `#CBD5E1`, text `#334155`. Hover transitions to `#F1F5F9` with border `#94A3B8`.
- **Destructive/Emergency Hazard Action**: Solid `#DC2626` background, `#FFFFFF` text, paired with high-visibility alert pulse icon.

### Chips & Sensor Tags
- **GIS Status Badges**: JetBrains Mono 10px uppercase (`label-caps`), 20px height, 2px radius, 6px horizontal padding.
  - Normal/Stable: Background `#ECFDF5`, text `#047857`, border 1px solid `#A7F3D0`.
  - Advisory/Displacement: Background `#FFF7ED`, text `#C2410C`, border 1px solid `#FDBA74`.
  - Critical Failure Risk: Background `#FEF2F2`, text `#B91C1C`, border 1px solid `#FCA5A5`.

### Input Fields & Layer Selectors
- **Numerical & Coordinate Coordinates**: Height 36px, background `#FFFFFF`, border 1px solid `#CBD5E1`, text `#0F172A` in JetBrains Mono. Focus state applies a 1px ring in `#059669` with `#F0FDF4` ambient field tint.
- **Search & Filter Bars**: Integrated leading iconography, placeholder text in `#64748B`, with keyboard navigation command prompts formatted as mono badges (`⌘K`).

### Lists, Grids & Data Feeds
- **Telemetry Event Log**: Striped alternating data rows (`#FFFFFF` and `#F8FAFC`). Row height locked to 32px. Columns delineated by hairline vertical dividers in `#E2E8F0`. Hovering a row highlights the perimeter in `#0284C7` (Secondary Cyan).

### Checkboxes, Radios & Switches
- **Layer Visibility Toggles**: 16px square with 2px radius. Inactive: border 1px solid `#94A3B8`, background `#FFFFFF`. Active: background `#059669`, featuring an SVG checkmark.
- **Instrument Switches**: Pill style (28px width, 16px height) with a 12px circular toggle thumb. Off: `#CBD5E1`; On: `#059669`.

### Cards & Inspector Panels
- **HUD Container Card**: Crisp `#FFFFFF` surface, 1px solid `#CBD5E1` border, 6px corner radius. Includes a standardized 32px header band containing Space Grotesk module titles, mono data point counts, and minimize/expand action icons.