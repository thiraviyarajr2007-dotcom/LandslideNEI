---
name: Geospatial Operations Engine
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3f4850'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#006399'
  on-secondary: '#ffffff'
  secondary-container: '#67bafd'
  on-secondary-container: '#004972'
  tertiary: '#006577'
  on-tertiary: '#ffffff'
  tertiary-container: '#008096'
  on-tertiary-container: '#f9fdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#cde5ff'
  secondary-fixed-dim: '#94ccff'
  on-secondary-fixed: '#001d32'
  on-secondary-fixed-variant: '#004b74'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 15px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.02em
  telemetry-display:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-xxs: 2px
  space-xs: 4px
  space-sm: 8px
  space-md: 12px
  space-lg: 16px
  space-xl: 20px
  space-2xl: 24px
  space-3xl: 32px
  dock-width-collapsed: 48px
  dock-width-expanded: 320px
  panel-header-height: 36px
  toolbar-height: 40px
  statusbar-height: 24px
---

## Brand & Style

This design system establishes an ultra-precise, high-density desktop workstation environment engineered for continuous situational awareness in Emergency Operations Centers (EOC) and geological hazard monitoring facilities. The visual aesthetic fuses mission-critical cartography with industrial instrumentation: austere, lucid, and resolutely operational. 

Every component balances dense telemetry readouts, spatial canvas overlays, and live incident queues. Visual hierarchy is established through meticulous value stepping and strict geometric rhythm rather than decorative embellishment. The emotional signature is calm under acute pressure, uncompromisingly accurate, and analytically authoritative.

## Colors

The palette is engineered for prolonged visual endurance in multi-monitor daylight and illuminated command center suites. Surfaces leverage cartographic zinc and steel values to prevent glare while maintaining high contrast across spatial layers.

### Surface Architecture
- **Base Canvas (`#f1f5f9`)**: Cool slate backplane for app framing, toolbars, and inactive viewport gutters.
- **Surface Layer 1 (`#f8fafc`)**: High-density panel containers, sidebars, layer manifests, and telemetry docks.
- **Surface Layer 2 (`#ffffff`)**: Elevated overlays, modal drawers, active viewport widgets, and direct input canvases.
- **Surface Inset (`#e2e8f0`)**: Recessed metric wells, scrubbers, and tabular zebra lines.

### Text & Chromatic Neutrals
- **Primary Ink (`#0f172a`)**: Primary typographic hierarchy, active coordinate values, and critical telemetry readouts.
- **Secondary Ink (`#334155`)**: Subheadings, active column headers, and structural labeling.
- **Muted Ink (`#64748b`)**: Metadata fields, unit denominations, inactive sensor channels, and non-blocking guides.
- **Border Structural (`#cbd5e1`)**: Framing dividers, panel splitters, and grid lines.
- **Border Subdued (`#e2e8f0`)**: Internal list delimiters, card partitions, and micro-grid ticks.

### Mission Accents & Focus
- **Active Precision Blue (`#0284c7`)**: Active layer selections, focused nodes, interactive map pins, and primary button fills.
- **Ocean Control (`#0077b6`)**: Pressed states, active GIS polyline borders, and primary navigation active rails.
- **Electric Cyan (`#06b6d4`)**: Real-time telemetry stream pulses, active sensor beacons, timeline scrub heads, and live vector heads.

### Hazard Threat Levels (USGS / EOC Standard)
- **Level 1 (Nominal / Stable)**: `#059669` (Emerald 600) — System clear, slope stability factor within nominal baseline ($FS > 1.5$).
- **Level 2 (Advisory / Watch)**: `#d97706` (Amber 600) — Saturated pore-water pressure, localized displacement detected.
- **Level 3 (High Warning)**: `#ea580c` (Orange 600) — Rapid shear velocity, imminent downslope movement warning.
- **Level 4 (Critical / Debris Flow)**: `#dc2626` (Crimson 600) — Active catastrophic failure, evacuation trigger active.

## Typography

Typographic scale is compressed and deliberate, tailored to information-dense dual and quad 4K monitor workstation layouts. 

- **Display & Headings (Space Grotesk)**: Chosen for structural legibility and technical rigor. Used strictly for window modules, telemetry header titles, incident callout labels, and sector zone codes.
- **Interface & Narrative (Inter)**: Handles descriptive GIS incident summaries, dispatch logs, settings screens, and context menus. Tabular figures must be enabled globally (`font-feature-settings: "tnum" 1, "cv05" 1`).
- **Data & Telemetry (JetBrains Mono)**: Renders all geospatial telemetry: UTM/MGRS coordinates, bore-hole inclinometer angles, rainfall accumulation rates ($mm/hr$), seismic frequency ($Hz$), and timestamps. All data grids use JetBrains Mono for exact vertical numeric alignment.

## Layout & Spacing

The workstation operates on a strict 4px sub-grid with an 8px primary component rhythm. The layout model is an invariant edge-to-edge docking architecture tailored for Windows 10/11 desktop window management.

### Spatial Architecture
- **Control Bar (Top - 40px)**: Global mission status, time-series mode (Live vs Playback), GIS coordinate system selection (WGS 84 / UTM), active operator credentials.
- **Fixed System Navigation Dock (Left - 48px)**: Primary icon rail linking Map Canvas, Sensor Array, InSAR Interferometry, Dispatch Log, System Admin.
- **Dynamic Workbench Split (Central Canvas)**: Fluid vector map display featuring configurable 2-up or 4-up quad-view splits with split-pane sizers.
- **Collapsible Telemetry Inspector (Right - 320px to 440px)**: Real-time sensor readout, kinematic slip-rate charts, alarm suppression matrix.
- **Auxiliary Timeline & Scrubber Tray (Bottom - 180px, collapsible to 28px)**: Geospatial rainfall threshold plots and temporal simulation sliders.
- **Status Monolith (Bottom - 24px)**: Fixed runtime parameters, ping latency, packet drops, active satellites, EPSG projection status.

Internal panel padding prioritizes data density: `space-sm` (8px) for condensed data lists and telemetry readouts; `space-md` (12px) for form inputs and control dialogs.

## Elevation & Depth

To preserve coordinate clarity on layered GIS vector canvases, this design system avoids diffuse ambient shadows. Elevation is conveyed strictly through high-contrast borders, hairline inner highlights, and structural tonal layering.

- **Level 0 (Recessed / Canvas)**: Baseline viewport and inset chart wells. Border: `1px solid #cbd5e1`. Background: `#f1f5f9`.
- **Level 1 (Docked Structural Panels)**: Sidebars, bottom temporal docks, toolbars. Border: `1px solid #cbd5e1`. Background: `#f8fafc`.
- **Level 2 (Contextual HUD & Floating Map Palettes)**: Map toolsets, measurement rulers, layer toggles. Border: `1px solid #94a3b8`. Background: `#ffffff`. Shadow: `0 1px 3px rgba(15, 23, 42, 0.08), 0 1px 2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal / Severe Threat Interventions)**: Critical alert notifications, diagnostic dialogs, sensor calibration windows. Border: `1px solid #64748b`. Background: `#ffffff`. Shadow: `0 8px 16px -2px rgba(15, 23, 42, 0.12), 0 4px 6px -2px rgba(15, 23, 42, 0.04)`.

## Shapes

The interface adopts a high-precision, industrial contour language. Structural components (docked panels, splitters, tabs, window frames) use sharp geometric terminals with `0px` radius to maintain perfect alignment with display screen edges. 

Interactive controls (buttons, input fields, dropdown triggers, and status chips) feature a micro-bevel of `0.25rem` (4px). Floating map HUD tools and toast popups leverage `0.25rem` (4px), maintaining crisp discipline across all monitor resolutions. Rounded pill styles are explicitly banned to prevent wasted spatial footprint in dense tables.

## Components

### Buttons
- **Primary**: Solid `#0284c7` fill, white `#ffffff` label, `4px` border radius, `28px` compact height for operational density. Hover: `#0077b6`. Focus: 2px ring of `#06b6d4` with 1px offset.
- **Secondary / Workstation Outlined**: Background `#ffffff`, border `1px solid #cbd5e1`, text `#0f172a`. Hover: Background `#f1f5f9`, border `#94a3b8`.
- **Destructive / Hazard Acknowledge**: Solid `#dc2626` background, `#ffffff` bold text. Used exclusively for overriding automated triggers or acknowledging Level 4 hazard warnings.

### Threat Level Status Chips
- Height: `20px`. Border-radius: `2px`. Font: `JetBrains Mono`, 10px, weight 600, uppercase.
- Layout: 6px solid circular status bead on left, text label on right.
- **Nominal (Low)**: Background `#ecfdf5`, border `#a7f3d0`, text `#065f46`, indicator `#059669`.
- **Advisory (Watch)**: Background `#fffbeb`, border `#fde68a`, text `#92400e`, indicator `#d97706`.
- **High Warning**: Background `#fff7ed`, border `#fed7aa`, text `#9a3412`, indicator `#ea580c`.
- **Critical (Action Imminent)**: Background `#fef2f2`, border `#fecaca`, text `#991b1b`, indicator `#dc2626` with synchronous 1Hz pulse animation.

### Data Tables & Sensor Lists
- Dense tabular rows with fixed `28px` row height.
- Header: `#f1f5f9` surface, `1px solid #cbd5e1` bottom border, `10px` JetBrains Mono all-caps tracking, text `#475569`.
- Striping: Alternating rows between `#ffffff` and `#f8fafc`. Active/selected row: `#e0f2fe` with a `2px` left border of `#0284c7`.
- Numeric Data: Always right-aligned with monospace font family and tabular figures enabled.

### Form Inputs & Telemetry Threshold Controls
- Height: `28px`. Background: `#ffffff`. Border: `1px solid #cbd5e1`. Font: `JetBrains Mono` 11px.
- Focus: Border color `#0284c7`, box-shadow `0 0 0 1px #0284c7`.
- Inline unit badges (e.g., $mm/h$, $kN/m^2$, $\mu\epsilon$) anchored to the right edge with `#f1f5f9` background and `#64748b` text.

### Checkboxes & Segmented Radio Switches
- Square checkboxes (14x14px), 2px radius, `#cbd5e1` border. Selected: Solid `#0284c7` with crisp white checkmark vector.
- Layer Visibility Toggles: Eye icon switch anchored within layer stack, transitioning from `#94a3b8` (hidden) to `#0284c7` (rendered).

### Cartographic Viewport Overlays (HUD)
- Semi-translucent panel overlay: `#ffffff` at 95% opacity with 4px backdrop blur, bordered by `1px solid #94a3b8`.
- Houses compass rose, coordinate readout HUD, crosshairs toggle, and multi-spectral layer blending sliders.