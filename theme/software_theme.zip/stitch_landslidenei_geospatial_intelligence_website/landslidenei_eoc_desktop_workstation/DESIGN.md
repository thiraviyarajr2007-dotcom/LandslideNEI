---
name: LANDSLIDENEI EOC Desktop Workstation
colors:
  surface: '#0b1325'
  surface-dim: '#0b1325'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e1f'
  surface-container-low: '#131b2d'
  surface-container: '#171f32'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3448'
  on-surface: '#dbe2fb'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dbe2fb'
  inverse-on-surface: '#283043'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#cdf3ff'
  on-tertiary: '#003640'
  tertiary-container: '#60e1ff'
  on-tertiary-container: '#006273'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#0b1325'
  on-background: '#dbe2fb'
  surface-variant: '#2d3448'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 15px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.03em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
  coordinate-stamp:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  titlebar-height: 2rem
  toolbar-height: 2.25rem
  panel-min-w: 18rem
  panel-max-w: 28rem
  gutter-compact: 0.25rem
  gutter-normal: 0.5rem
  gutter-spacious: 0.75rem
  pad-cell: 0.375rem
  pad-panel: 0.75rem
  pad-window: 0.5rem
---

## Brand & Style

This design system targets geotechnical engineers, emergency operations center (EOC) controllers, and municipal crisis coordinators operating high-density desktop monitoring workstations. The interface establishes uncompromising operational authority: calm under pressure, rigorously structured, hyper-legible, and engineered for sustained 12-hour shifts in low-ambient-light command centers.

The visual style blends Windows 11 Enterprise desktop software ergonomics (Mica-inspired deep layered surfaces, discrete window controls, high-density tool strips) with advanced GIS instrumentation aesthetics. It emphasizes low visual noise, deterministic spatial indexing, micro-tactile status communication, and razor-sharp data visualization boundaries.

## Colors

The palette leverages a deep midnight navy-to-obsidian spatial substrate paired with an electric cyan telemetry primary and situational alert tokens.

### Canvas & Surface Architecture
- **Base Canvas (App Frame Backing):** `#070B14`
- **Surface Level 1 (Panels, Drawers, Sidebars):** `#0D1527`
- **Surface Level 2 (Cards, Inspectors, Modal Overlays):** `#152238`
- **Surface Level 3 (Input wells, Metric cards, Active states):** `#1C2E4C`

### Accent & Interaction Layers
- **Primary Accent (`#00E5FF`):** Reserved for focal focal interactive targets, active geospatial layers, selected polygon bounds, and primary command triggers.
- **Secondary Accent (`#38BDF8`):** Informational callouts, active coordinate crosshairs, secondary graphs, and hover focus states.
- **Sub-tier Accent (`#06B6D4`):** Secondary controls, subtle chart lines, active toggle backgrounds.

### Operational Risk Indicators
- **Operational Normal / Low:** `#10B981` (Emerald) - Stable slope, nominal telemetry
- **Advisory / Watch:** `#F59E0B` (Amber) - Displacement acceleration threshold 1
- **Warning / High:** `#F97316` (Orange) - Soil pore saturation critical
- **Emergency / Critical:** `#EF4444` (Vivid Crimson) - Structural failure imminent

### Stroke & Structural Dividers
- **Subtle Surface Boundary:** `#1E293B`
- **Interactive Component Outline:** `#334155`
- **High-Focus / Precision Accent Stroke:** `#00E5FF`

## Typography

Typography enforces strict operational hierarchy across tight spatial confines. `Space Grotesk` governs human-authored text, section titles, headers, and UI narratives. `JetBrains Mono` handles all numerical readouts, UTM/WGS84 coordinates, sensor serial identifiers, timestamps, and elevation vectors to ensure fixed-column numeric scanning without visual drift.

All typography renders with subpixel font smoothing on dark backgrounds. Heading scales remain compact (maxing out at 24px) to preserve GIS viewport area and maintain maximum multi-panel visibility on 1440p and 4K command-center monitors.

## Layout & Spacing

The layout is architectured as a multi-dock desktop frame modeled after Windows 11 enterprise operations consoles:

- **App Shell:** A unified 32px native/custom title bar carrying window status, global connection health, sync pulse, and standard minimization controls.
- **Top Command Strip:** 36px high-density toolbar housing global GIS tools (layer management, measurement vectors, time-slider scrubbers, situational snapshots).
- **Core Viewport:** Dynamic-split layout anchored by a central GIS Map canvas flanked by collapsible side inspectors (`panel-min-w: 288px`, `panel-max-w: 448px`).
- **Telemetry Grid:** Sub-panels leverage an 8-column internal dense grid with 4px or 8px gutters, maximizing information density without visual crowding.
- **Micro Spacing Units:** UI components utilize a base-4 grid system (2px, 4px, 8px, 12px, 16px). Margins within inspection decks are strictly clamped to 8px or 12px to maximize data density per square inch.

## Elevation & Depth

Visual hierarchy does not rely on ambient diffused dropshadows, which create perceptual mud on multi-monitor command walls. Instead, depth is established through tonal stacking, backdrop filtration, and hairline borders:

1. **Base Layer (Elevation 0 - Map & Root Canvas):** `#070B14`, raw display surface.
2. **Docked Surfaces (Elevation 1 - Sidebars, Toolbars):** `#0D1527` with 1px border `rgba(30, 41, 59, 0.8)`.
3. **Floating Overlays & HUD Viewports (Elevation 2):** `#152238` with 85% opacity, `backdrop-filter: blur(12px)` (Mica-effect simulation), and 1px border `#334155`.
4. **Active Flight / Popover Cards (Elevation 3):** `#1C2E4C` encased by 1px border `#00E5FF` at 40% alpha, coupled with an inset `0 0 12px rgba(0, 229, 255, 0.08)` perimeter glow for active sensor targets.
5. **Critical Incident Modals:** Backdrop obscured with `#070B14` at 70% opacity; modal panel elevated via solid `#152238` bounded by a 1px `#EF4444` structural stroke.

## Shapes

The design system employs a disciplined, engineering-grade shape language (`roundedness: 1`):

- **Standard Buttons, Inputs, Chips:** 4px (`0.25rem`) corner radius.
- **Floating HUD Tiles & Panels:** 6px to 8px (`0.375rem` - `0.5rem`) corner radius, honoring Windows 11 Fluent guidelines without sacrificing screen real estate.
- **Map Pinheads & Sensor Nodes:** Perfect circles (`50%` radius) or diamond hazard matrices (`rotate 45deg`) for rapid visual classification.
- **Window Frames & Shell Boundaries:** Sharp or 8px outer boundary matching OS compositor conventions.

## Components

### Buttons & Interactive Triggers
- **Primary Action (Command Execute):** Solid `#00E5FF` fill with `#070B14` text, `font-weight: 600`, 4px radius, 28px height. On hover, background shifts to `#38BDF8`.
- **Secondary Action (Query / Layer Toggle):** `#152238` background, 1px `#334155` border, `#F8FAFC` text. On hover, border updates to `#00E5FF` at 60% alpha.
- **Destructive / Alert Action:** Dark crimson tint `#2D1219` background, 1px `#EF4444` border, `#FCA5A5` text. Hover shifts to solid `#EF4444` with `#FFFFFF` text.
- **Compact Icon Action (Tool strip):** 28x28px borderless button, `#94A3B8` icon. On hover, background `#1E293B`, icon turns `#00E5FF`.

### Telemetry Badges & Chips
- **Risk Indicator Badges:** 20px height, 4px radius, 6px horizontal padding. Composed of an 8px pulsing status circle beside uppercase `JetBrains Mono` text (`label-caps`).
  - *Low:* BG `rgba(16, 185, 129, 0.12)`, Border `rgba(16, 185, 129, 0.4)`, Text `#34D399`
  - *Watch:* BG `rgba(245, 158, 11, 0.12)`, Border `rgba(245, 158, 11, 0.4)`, Text `#FBBF24`
  - *High:* BG `rgba(249, 115, 22, 0.12)`, Border `rgba(249, 115, 22, 0.4)`, Text `#FB923C`
  - *Critical:* BG `rgba(239, 68, 68, 0.16)`, Border `rgba(239, 68, 68, 0.7)`, Text `#F87171`

### Input Fields & Search Bars
- **Desktop Search / Coordinate Input:** 28px height, `#0D1527` background, 1px `#1E293B` border, `#F8FAFC` text in `JetBrains Mono`. Focus state applies 1px `#00E5FF` border and a faint 2px outer cyan ring (`rgba(0, 225, 255, 0.2)`).
- **Coordinate Stepper / Range Selectors:** Compact dual-input wells paired with monospace readouts and 20px stepper arrows.

### Data Tables & List Panels
- **Header Rows:** `#0D1527` surface, 24px height, uppercase `label-caps` in `#64748B`, bottom border 1px `#1E293B`.
- **Data Rows:** 28px height, alternating transparent and `rgba(21, 34, 56, 0.3)` background. Hover renders `rgba(0, 229, 255, 0.05)` highlight. Numerical values right-aligned in `JetBrains Mono`.

### Inspection Cards
- **Inspector Deck Card:** Background `#152238`, 1px solid `#1E293B` outline, 6px radius. Header strip features an icon, sensor ID stamp, and a risk status badge. Inner body contains live Sparklines (1.5px stroke width) and displacement vector parameters.

### Native Windows Frame Elements
- **Title Bar:** 32px height, seamless `#070B14`, draggable window canvas, subtle white application icon, centered status text ("LANDSLIDENEI - Sector 4 Active Monitoring"), and standard Windows window control glyphs (Minimize, Maximize, Close) with hover highlights.